"""SkillTree local core."""

__version__ = "0.4.1"
